/**
 * 
 */
/**
 * 
 */
module Mastermind {
	requires org.junit.jupiter.api;
}