package configuracao;

public class ListaConfiguracoes {

}
