package configuracao;

public class Configuracao {
	
	private String alfabeto;
	
	public String getAlfabeto() {
		return alfabeto;
	}

	public void setAlfabeto (String alfabeto) {
		this.alfabeto = alfabeto;
	}
}
