package configuration;

public class ListaConfiguracoes {

}
