/**
 * 
 */
/**
 * 
 */
module Matermind {
	requires org.junit.jupiter.api;
	requires java.desktop;
}