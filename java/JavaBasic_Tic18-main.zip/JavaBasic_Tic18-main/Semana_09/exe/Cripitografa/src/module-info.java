/**
 * 
 */
/**
 * 
 */
module Cripitografa {
	requires java.desktop;
}