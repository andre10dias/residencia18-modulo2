package DAO;

public class FalhaDistribucao_DAO {

}
