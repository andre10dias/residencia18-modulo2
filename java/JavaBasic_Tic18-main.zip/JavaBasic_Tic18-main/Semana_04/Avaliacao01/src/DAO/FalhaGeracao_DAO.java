package DAO;

public class FalhaGeracao_DAO {

}
