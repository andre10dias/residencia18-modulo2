package Facade;

public class Facade {
	
}
