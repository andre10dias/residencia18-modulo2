package view;

public class UserInterface {
	public static void main(String[] args) {
		int opc, opc2;
		
		
	}
}
