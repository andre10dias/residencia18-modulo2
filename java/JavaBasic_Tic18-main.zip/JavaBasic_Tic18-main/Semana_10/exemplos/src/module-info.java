/**
 * 
 */
/**
 * 
 */
module TesteBD {
	requires java.sql;
}