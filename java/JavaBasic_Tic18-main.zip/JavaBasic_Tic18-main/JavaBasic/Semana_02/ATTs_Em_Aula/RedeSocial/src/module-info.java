/**
 * 
 */
/**
 * 
 */
module RedeSocial {
	requires java.desktop;
}