
module Conjugador {
	
	
}