package ClienteExcercoes;

public class UsuarioBloqueadoException extends RuntimeException{

}
