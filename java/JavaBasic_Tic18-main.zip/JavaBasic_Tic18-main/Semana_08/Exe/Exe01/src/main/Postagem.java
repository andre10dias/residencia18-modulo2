package main;

public class Postagem {

}
